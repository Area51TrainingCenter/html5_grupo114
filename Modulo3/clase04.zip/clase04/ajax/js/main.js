function ver_detalle(){
	alert("hizo click en mi elemento");
}

function initMap(){
	console.log("esta funcion se va a ejecutar cuando se termine de cargar el mapa")

}
function ver_mapa(longitud,latitud){
	//

	let opciones={
		center: {lat: latitud, lng: longitud},
		zoom:17
	}

	//let mapa=new google.maps.Map(elemento , opciones)
	let mapa=new google.maps.Map(document.getElementById('mapa'),opciones);


	let opciones_maker={
		position:{lat: latitud, lng: longitud},
		title:"SItio 1",
		map:mapa,
		animation:google.maps.Animation.BOUNCE,
		icon:"https://www.cocacola.es/content/dam/GO/CokeZone/Common/global/logo/logodesktop/coca-cola-logo-260x260.png"
	}
	let marker=new google.maps.Marker(opciones_maker)

	/*let marker2=new google.maps.Marker({
		position:{lat: latitud, lng: longitud},
		map:mapa
	})*/


}
function saludo(){
	alert("click");
}
$(function(){

				
	/*$("#lista-usuarios li").click(function(){
		alert("hizo click");
	})*/
	$("#btn-obtener-usuarios").click(function(){
		//,
		let parametros_ajax={
			url:"http://sminnova.com/restapitrujillo/sitiosturisticos",
			//data:{dni:"123",codigo:"abc"},
			type:"GET",
			dataType:"json",
			success:function(datos){ 
				//let limite=datos.length;
				//console.log(datos);
				$("#lista-usuarios").html("");
				for(var i=0; i<datos.length; i++){
					//console.log(datos[i].nombre)
					//console.log(datos[i].foto_principal)

		$("#lista-usuarios").append(`
			<li onclick="ver_mapa(${datos[i].longitud},${datos[i].latitud})" data-longitud="${datos[i].longitud}" data-latitud="${datos[i].latitud}">
			<img class="circulo" src="${datos[i].foto_principal}"> 
			${datos[i].nombre}
			</li>`)
					/*$("#lista-usuarios").append('<li>'
					+'<h2 class="nombre">'+datos[i].name+ '</h2>'
					+'<span class="email">Email : '+datos[i].email+ '</span>'
					+'<span class="ciudad">Ciudad: '+datos[i].address.city+ ' </span>'
					+'<span class="lat">Lat: '+datos[i].address.geo.lat+ ' </span> <span class="lng">Long: '+datos[i].address.geo.lng+ ' </span>'
				+'</li>');*/

					/*$("#lista-usuarios").append(`<li >
					<h2 class="nombre" onclick="ver_detalle()">${datos[i].name}</h2>
					<span class="email">Email : ${datos[i].email}</span>
					<span class="ciudad">Ciudad: ${datos[i].address.city} </span>
					<span class="lat">Lat: ${datos[i].address.geo.lat}</span> <span class="lng">Long: ${datos[i].address.geo.lng} </span>

					</li>`)*/
				}


			/*	console.log(datos[0].name) 
				console.log(datos[0].email) 
				console.log(datos[0].address) 
				console.log(datos[0].address.city) 
				console.log(datos[0].address.geo) 
				console.log(datos[0].address.geo.lat)
				console.log(datos[0].address.geo.lng)*/  
			},
			error:function(){console.log("error")},
			complete:function(){console.log("completado")},
		}

		$.ajax(parametros_ajax)


		
	})
})