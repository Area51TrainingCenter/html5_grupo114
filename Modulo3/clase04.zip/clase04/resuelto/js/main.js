$("#obtener").click(function(){

	let parametros={
		ulr:"https://sminnova.com/restapitrujillo/sitiosturisticos",
		type:"GET",
		dataType:"json",
		success: function(respuesta){
			console.log(respuesta);
		},
		error: function(){},
		complete :function(){}
	}

	$.ajax(parametros);

})